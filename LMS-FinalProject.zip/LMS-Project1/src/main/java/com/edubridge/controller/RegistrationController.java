package com.edubridge.controller;


	import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.http.HttpStatus;
	import org.springframework.http.ResponseEntity;
	import org.springframework.web.bind.annotation.CrossOrigin;
	import org.springframework.web.bind.annotation.PostMapping;
	import org.springframework.web.bind.annotation.RequestBody;
	import org.springframework.web.bind.annotation.RestController;

	import com.edubridge.model.Professor;
	import com.edubridge.model.User;
	import com.edubridge.service.ProfessorService;
	import com.edubridge.service.UserService;

	@RestController
	@CrossOrigin(origins = "http://localhost:4200")//4200

	public class RegistrationController 
	{
		@Autowired
		private UserService userService;
		
		@Autowired
		private ProfessorService professorService;
		
		@PostMapping("/registeruser")
		public ResponseEntity<User> registerUser(@RequestBody User user) throws Exception
		{
			
		User userObj = userService.saveUser(user);
			return new ResponseEntity<User>(userObj,HttpStatus.OK);
		}
		
		@PostMapping("/registerprofessor")
		
		//@CrossOrigin(origins = "http://localhost:4200")
		
		public ResponseEntity<Professor> registerprofessor(@RequestBody Professor professor) throws Exception
		{
			
			Professor professorObj = null;
			professorObj = professorService.saveProfessor(professor);
			return new ResponseEntity<Professor>(professorObj,HttpStatus.OK);
		}
		
		
	}


